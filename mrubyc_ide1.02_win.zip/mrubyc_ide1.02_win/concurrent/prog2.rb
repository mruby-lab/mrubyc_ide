pinMode(1,0)
while true
  digitalWrite(1,1)
  sleep 0.1
  digitalWrite(1,0)
  sleep 0.1
end