pinMode(0,0)
while true
  digitalWrite(0,1)
  sleep 0.5
  digitalWrite(0,0)
  sleep 0.5
end
